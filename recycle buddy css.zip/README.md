# Recycle Buddy

A comprehensive waste management platform that connects users with waste management facilities for efficient waste collection and recycling.

## Table of Contents

- [Overview](#overview)
- [Features](#features)
- [Project Structure](#project-structure)
- [Setup and Installation](#setup-and-installation)
- [Database Integration](#database-integration)
- [Android App Integration](#android-app-integration)
- [AI Model Integration](#ai-model-integration)
- [Customization](#customization)
- [Deployment](#deployment)

## Overview

Recycle Buddy is a Next.js application that allows users to report waste by uploading photos and providing location information. Waste management facilities can then browse available pickups, schedule collection times, and mark pickups as completed.

## Features

- **User Features**:
  - Report waste with photos and location
  - Track waste collection status
  - View scheduled pickups
  - Receive notifications when pickups are scheduled or completed

- **Facility Features**:
  - Browse available waste pickups
  - View waste locations on a map
  - Schedule pickups with date, time, and vehicle type
  - Mark pickups as completed
  - Manage facility profile

- **Admin Features**:
  - Manage all waste reports
  - Monitor facility activities
  - View analytics and statistics

## Project Structure

\`\`\`
recycle-buddy/
├── app/                    # Next.js App Router
│   ├── actions.ts          # Server actions for data operations
│   ├── admin/              # Admin dashboard pages
│   ├── api/                # API routes for Android integration
│   ├── dashboard/          # User dashboard pages
│   ├── docs/               # Documentation pages
│   ├── facilities/         # Facility portal pages
│   ├── globals.css         # Global CSS styles
│   ├── layout.tsx          # Root layout
│   ├── page.tsx            # Home page
│   ├── profile/            # User profile page
│   ├── reports/            # Report details pages
│   ├── success/            # Success page after report submission
│   └── upload/             # Waste report upload page
├── components/             # Reusable UI components
├── lib/                    # Utility functions and libraries
│   ├── supabase.ts         # Supabase client
│   └── utils.ts            # Helper functions
├── public/                 # Static assets
└── README.md               # Project documentation
\`\`\`

## Setup and Installation

1. **Clone the repository**:
   \`\`\`bash
   git clone https://github.com/yourusername/recycle-buddy.git
   cd recycle-buddy
   \`\`\`

2. **Install dependencies**:
   \`\`\`bash
   npm install
   \`\`\`

3. **Set up environment variables**:
   Create a `.env.local` file in the root directory with the following variables:
   \`\`\`
   # Supabase
   NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
   NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
   
   # Vercel Blob Storage
   BLOB_READ_WRITE_TOKEN=your_blob_token
   
   # AI Model (if using)
   AI_API_KEY=your_ai_api_key
   \`\`\`

4. **Run the development server**:
   \`\`\`bash
   npm run dev
   \`\`\`

5. **Open your browser** and navigate to `http://localhost:3000`

## Database Integration

### Supabase Setup

1. Create a Supabase project at [supabase.com](https://supabase.com)
2. Set up the following tables:

#### Users Table
\`\`\`sql
CREATE TABLE public.profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    email TEXT NOT NULL,
    full_name TEXT,
    address TEXT,
    phone TEXT,
    avatar_url TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL
);
\`\`\`

#### Waste Reports Table
\`\`\`sql
CREATE TABLE public.waste_reports (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
    image_url TEXT,
    location TEXT NOT NULL,
    coordinates TEXT,
    description TEXT,
    category TEXT NOT NULL,
    status TEXT DEFAULT 'pending' NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL
);
\`\`\`

#### Facilities Table
\`\`\`sql
CREATE TABLE public.facilities (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    phone TEXT,
    address TEXT NOT NULL,
    description TEXT,
    service_area NUMERIC,
    waste_types TEXT[],
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL
);
\`\`\`

#### Pickups Table
\`\`\`sql
CREATE TABLE public.pickups (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    report_id UUID REFERENCES public.waste_reports(id) ON DELETE CASCADE,
    facility_id UUID REFERENCES public.facilities(id),
    scheduled_date DATE NOT NULL,
    time_from TIME NOT NULL,
    time_to TIME NOT NULL,
    vehicle_type TEXT,
    status TEXT DEFAULT 'scheduled' NOT NULL,
    notes TEXT,
    completion_photo_url TEXT,
    completion_notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
    completed_at TIMESTAMP WITH TIME ZONE
);
\`\`\`

3. Set up Row Level Security (RLS) policies for each table
4. Create the Supabase client in your application:

\`\`\`typescript
// lib/supabase.ts
import { createClient } from '@supabase/supabase-js'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL as string
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY as string

export const supabase = createClient(supabaseUrl, supabaseAnonKey)
\`\`\`

## Android App Integration

### API Endpoints

The application provides the following API endpoints for Android integration:

- **Authentication**: `/api/auth`
  - POST: Login and get authentication token

- **Reports**: `/api/reports`
  - GET: Fetch all reports or filter by user ID
  - POST: Create a new waste report

- **Report Details**: `/api/reports/[id]`
  - GET: Get a specific report
  - PATCH: Update a report (e.g., schedule pickup)
  - DELETE: Delete a report

- **Image Upload**: `/api/upload`
  - POST: Upload an image and get a URL

### Android Implementation

1. **Create API Client**:
   ```kotlin
   // RetrofitClient.kt
   object RetrofitClient {
       private const val BASE_URL = "https://your-recycle-buddy-app.vercel.app/api/"
       
       private val client = OkHttpClient.Builder()
           .addInterceptor(AuthInterceptor())
           .build()
           
       val instance: Retrofit by lazy {
           Retrofit.Builder()
               .baseUrl(BASE_URL)
               .addConverterFactory(GsonConverterFactory.create())
               .client(client)
               .build()
       }
   }
   \`\`\`

2. **Define API Interfaces**:
   ```kotlin
   // RecycleBuddyApi.kt
   interface RecycleBuddyApi {
       @POST("auth")
       suspend fun login(@Body loginRequest: LoginRequest): Response<AuthResponse>
       
       @GET("reports")
       suspend fun getReports(@Query("userId") userId: String? = null): Response<List<WasteReport>>
       
       @POST("reports")
       suspend fun createReport(@Body report: WasteReport): Response<WasteReport>
       
       @Multipart
       @POST("upload")
       suspend fun uploadImage(
           @Part image: MultipartBody.Part
       ): Response<UploadResponse>
   }
   \`\`\`

3. **Create Data Models**:
   ```kotlin
   // WasteReport.kt
   data class WasteReport(
       val id: String? = null,
       val imageUrl: String? = null,
       val location: String,
       val description: String? = null,
       val category: String,
       val status: String = "pending",
       val date: String? = null,
       val time: String? = null,
       val facility: String? = null,
       val userId: String? = null
   )
   \`\`\`

4. **Implement Authentication**:
   ```kotlin
   // AuthInterceptor.kt
   class AuthInterceptor : Interceptor {
       override fun intercept(chain: Interceptor.Chain): Response {
           val request = chain.request()
           val token = SharedPrefsManager.getToken()
           
           return if (token != null) {
               val newRequest = request.newBuilder()
                   .header("Authorization", "Bearer $token")
                   .build()
               chain.proceed(newRequest)
           } else {
               chain.proceed(request)
           }
       }
   }
   \`\`\`

5. **Implement Data Synchronization**:
   ```kotlin
   // SyncWorker.kt
   class SyncWorker(
       context: Context,
       params: WorkerParameters
   ) : CoroutineWorker(context, params) {
       private val repository = ReportRepository()
       
       override suspend fun doWork(): Result {
           try {
               val userId = SharedPrefsManager.getUserId() ?: return Result.failure()
               
               // Fetch latest reports from server
               val response = repository.getReports(userId)
               if (response.isSuccessful) {
                   val reports = response.body() ?: emptyList()
                   // Update local database
                   AppDatabase.getInstance(applicationContext).reportDao().insertAll(reports)
                   return Result.success()
               }
               return Result.retry()
           } catch (e: Exception) {
               return Result.failure()
           }
       }
   }
   \`\`\`

## AI Model Integration

You can integrate an AI model to enhance the waste categorization process:

1. **Set up an AI service provider** (e.g., OpenAI, Hugging Face, or your custom model)
2. **Create an AI client**:

\`\`\`typescript
// lib/ai.ts
import { Configuration, OpenAIApi } from 'openai'

const configuration = new Configuration({
  apiKey: process.env.AI_API_KEY,
})

const openai = new OpenAIApi(configuration)

export async function classifyWaste(imageBase64: string): Promise<string> {
  try {
    const response = await openai.createCompletion({
      model: "gpt-4-vision-preview",
      messages: [
        {
          role: "user",
          content: [
            { type: "text", text: "Classify this waste image into one of these categories: E-Waste, General Waste, Plastic, Paper, Glass, Metal, Organic" },
            { type: "image_url", image_url: { url: `data:image/jpeg;base64,${imageBase64}` } }
          ]
        }
      ],
      max_tokens: 50
    })
    
    return response.data.choices[0].message.content.trim()
  } catch (error) {
    console.error('Error classifying waste:', error)
    return 'General Waste' // Default fallback
  }
}
\`\`\`

3. **Integrate with the upload process**:

\`\`\`typescript
// app/upload/page.tsx
import { classifyWaste } from '@/lib/ai'

// Inside your component:
const handleImageUpload = async (file: File) => {
  // Convert file to base64
  const reader = new FileReader()
  reader.readAsDataURL(file)
  reader.onload = async () => {
    const base64 = reader.result?.toString().split(',')[1]
    if (base64) {
      // Get AI classification
      const category = await classifyWaste(base64)
      setCategory(category)
    }
  }
}
\`\`\`

## Customization

### Changing the Website Name

1. Update all occurrences of "Recycle Buddy" in the codebase:
   - `app/page.tsx`
   - `app/layout.tsx` (title and metadata)
   - All header components

2. Update the logo if needed:
   - Replace the `<Recycle />` icon with your custom logo
   - Or modify the styling of the existing icon

### Modifying the Color Scheme

1. Edit the CSS variables in `app/globals.css`:
   \`\`\`css
   :root {
     --primary: #4CAF50; /* Change to your primary color */
     --primary-hover: #388E3C; /* Change to a darker shade */
     /* Update other color variables as needed */
   }
   \`\`\`

### Adding New Waste Categories

1. Update the category selection in `app/upload/page.tsx`:
   \`\`\`tsx
   <div className="grid grid-cols-3 gap-2">
     <button
       type="button"
       className={`btn ${category === "E-Waste" ? "btn-primary" : "btn-outline"}`}
       onClick={() => setCategory("E-Waste")}
     >
       E-Waste
     </button>
     <button
       type="button"
       className={`btn ${category === "General Waste" ? "btn-primary" : "btn-outline"}`}
       onClick={() => setCategory("General Waste")}
     >
       General Waste
     </button>
     <button
       type="button"
       className={`btn ${category === "Recyclables" ? "btn-primary" : "btn-outline"}`}
       onClick={() => setCategory("Recyclables")}
     >
       Recyclables
     </button>
     {/* Add more categories as needed */}
   </div>
   \`\`\`

2. Update the database schema to accommodate new categories

## Deployment

### Vercel Deployment

1. Push your code to a GitHub repository
2. Connect your repository to Vercel
3. Configure environment variables in the Vercel dashboard
4. Deploy your application

### Custom Server Deployment

1. Build the application:
   \`\`\`bash
   npm run build
   \`\`\`

2. Start the production server:
   \`\`\`bash
   npm start
   \`\`\`

## License

This project is licensed under the MIT License - see the LICENSE file for details.
\`\`\`

Let's create a file for AI model integration:

import { Configuration, OpenAIApi } from "openai"

// Initialize the OpenAI configuration
const configuration = new Configuration({
  apiKey: process.env.AI_API_KEY,
})

const openai = new OpenAIApi(configuration)

/**
 * Classifies waste based on an image using AI
 * @param imageBase64 Base64 encoded image
 * @returns Predicted waste category
 */
export async function classifyWaste(imageBase64: string): Promise<string> {
  try {
    const response = await openai.createCompletion({
      model: "gpt-4-vision-preview",
      messages: [
        {
          role: "user",
          content: [
            {
              type: "text",
              text: "Classify this waste image into one of these categories: E-Waste, General Waste, Plastic, Paper, Glass, Metal, Organic",
            },
            { type: "image_url", image_url: { url: `data:image/jpeg;base64,${imageBase64}` } },
          ],
        },
      ],
      max_tokens: 50,
    })

    return response.data.choices[0].message.content.trim()
  } catch (error) {
    console.error("Error classifying waste:", error)
    return "General Waste" // Default fallback
  }
}

/**
 * Generates a description for waste based on an image
 * @param imageBase64 Base64 encoded image
 * @returns Generated description
 */
export async function generateWasteDescription(imageBase64: string): Promise<string> {
  try {
    const response = await openai.createCompletion({
      model: "gpt-4-vision-preview",
      messages: [
        {
          role: "user",
          content: [
            {
              type: "text",
              text: "Describe this waste in 1-2 sentences, mentioning what it is and how it should be disposed of.",
            },
            { type: "image_url", image_url: { url: `data:image/jpeg;base64,${imageBase64}` } },
          ],
        },
      ],
      max_tokens: 100,
    })

    return response.data.choices[0].message.content.trim()
  } catch (error) {
    console.error("Error generating waste description:", error)
    return "" // Empty string fallback
  }
}

/**
 * Provides recycling tips based on waste category
 * @param category Waste category
 * @returns Recycling tips
 */
export async function getRecyclingTips(category: string): Promise<string> {
  try {
    const response = await openai.createCompletion({
      model: "gpt-4",
      messages: [
        {
          role: "user",
          content: `Provide 3 short recycling tips for ${category}.`,
        },
      ],
      max_tokens: 150,
    })

    return response.data.choices[0].message.content.trim()
  } catch (error) {
    console.error("Error getting recycling tips:", error)
    return "No recycling tips available at the moment." // Fallback
  }
}

import { createClient } from "@supabase/supabase-js"

// Get environment variables
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL as string
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY as string

// Create Supabase client
export const supabase = createClient(supabaseUrl, supabaseAnonKey)

/**
 * Fetches waste reports from the database
 * @param userId Optional user ID to filter reports
 * @returns Array of waste reports
 */
export async function getWasteReports(userId?: string) {
  let query = supabase.from("waste_reports").select("*")

  if (userId) {
    query = query.eq("user_id", userId)
  }

  const { data, error } = await query.order("created_at", { ascending: false })

  if (error) {
    console.error("Error fetching waste reports:", error)
    return []
  }

  return data || []
}

/**
 * Fetches a single waste report by ID
 * @param id Report ID
 * @returns Waste report or null
 */
export async function getWasteReportById(id: string) {
  const { data, error } = await supabase.from("waste_reports").select("*, pickups(*)").eq("id", id).single()

  if (error) {
    console.error("Error fetching waste report:", error)
    return null
  }

  return data
}

/**
 * Creates a new waste report
 * @param report Waste report data
 * @returns Created report or null
 */
export async function createWasteReport(report: any) {
  const { data, error } = await supabase.from("waste_reports").insert(report).select().single()

  if (error) {
    console.error("Error creating waste report:", error)
    return null
  }

  return data
}

/**
 * Updates a waste report
 * @param id Report ID
 * @param updates Updates to apply
 * @returns Updated report or null
 */
export async function updateWasteReport(id: string, updates: any) {
  const { data, error } = await supabase.from("waste_reports").update(updates).eq("id", id).select().single()

  if (error) {
    console.error("Error updating waste report:", error)
    return null
  }

  return data
}

/**
 * Schedules a pickup for a waste report
 * @param pickup Pickup data
 * @returns Created pickup or null
 */
export async function schedulePickup(pickup: any) {
  const { data, error } = await supabase.from("pickups").insert(pickup).select().single()

  if (error) {
    console.error("Error scheduling pickup:", error)
    return null
  }

  // Update the waste report status
  await updateWasteReport(pickup.report_id, { status: "scheduled" })

  return data
}

/**
 * Marks a pickup as completed
 * @param id Pickup ID
 * @param completionData Completion data
 * @returns Updated pickup or null
 */
export async function completePickup(id: string, completionData: any) {
  const { data, error } = await supabase
    .from("pickups")
    .update({
      ...completionData,
      status: "completed",
      completed_at: new Date().toISOString(),
    })
    .eq("id", id)
    .select()
    .single()

  if (error) {
    console.error("Error completing pickup:", error)
    return null
  }

  // Update the waste report status
  await updateWasteReport(data.report_id, { status: "completed" })

  return data
}

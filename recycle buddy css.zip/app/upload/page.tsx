"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Loader2, MapPin, Upload, ArrowLeft, Recycle } from "lucide-react"
import { createWasteReport } from "@/app/actions"

export default function UploadPage() {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [imagePreview, setImagePreview] = useState<string | null>(null)
  const [location, setLocation] = useState("")
  const [description, setDescription] = useState("")
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [category, setCategory] = useState<string>("")

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setSelectedFile(file)
      const reader = new FileReader()
      reader.onloadend = () => {
        setImagePreview(reader.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleGetLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords
          setLocation(`${latitude}, ${longitude}`)
        },
        (error) => {
          console.error("Error getting location:", error)
          alert("Unable to get your location. Please enter it manually.")
        },
      )
    } else {
      alert("Geolocation is not supported by your browser. Please enter your location manually.")
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!selectedFile || !location || !category) {
      alert("Please provide an image, location, and waste category")
      return
    }

    setIsLoading(true)

    try {
      // In a real implementation, you would upload the image to Blob storage
      // and save the report details to your database
      await createWasteReport({
        imageUrl: "placeholder-image-url",
        location,
        description,
        category,
        status: "pending",
      })

      router.push("/success")
    } catch (error) {
      console.error("Error submitting report:", error)
      alert("Failed to submit your report. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex flex-col min-h-screen">
      <header className="header">
        <Link href="/" className="header-logo">
          <Recycle className="text-primary" style={{ width: "1.5rem", height: "1.5rem" }} />
          <span className="text-lg">Recycle Buddy</span>
        </Link>
      </header>
      <main className="flex-1 flex items-center justify-center p-4 md:p-8">
        <div className="card" style={{ maxWidth: "28rem", width: "100%" }}>
          <div className="card-header">
            <div className="flex items-center gap-2">
              <Link href="/">
                <button className="btn btn-icon btn-secondary">
                  <ArrowLeft style={{ width: "1rem", height: "1rem" }} />
                </button>
              </Link>
              <div>
                <h2 className="card-title">Report Waste</h2>
                <p className="card-description">Upload a photo and provide your location</p>
              </div>
            </div>
          </div>
          <form onSubmit={handleSubmit}>
            <div className="card-content">
              <div className="form-group">
                <label className="label" htmlFor="image">
                  Waste Photo
                </label>
                <div className="flex flex-col items-center justify-center gap-4">
                  {imagePreview ? (
                    <div className="relative w-full aspect-video rounded overflow-hidden border">
                      <img
                        src={imagePreview || "/placeholder.svg"}
                        alt="Waste preview"
                        style={{ objectFit: "cover", width: "100%", height: "100%" }}
                      />
                      <button
                        type="button"
                        className="btn btn-secondary btn-sm"
                        style={{ position: "absolute", bottom: "0.5rem", right: "0.5rem" }}
                        onClick={() => {
                          setImagePreview(null)
                          setSelectedFile(null)
                        }}
                      >
                        Change
                      </button>
                    </div>
                  ) : (
                    <div className="border border-dashed rounded p-8 w-full flex flex-col items-center gap-4">
                      <Upload className="text-gray-400" style={{ width: "2rem", height: "2rem" }} />
                      <div className="text-center">
                        <p className="text-sm text-gray-500">Click to upload or drag and drop</p>
                        <p className="text-xs text-gray-400">PNG, JPG or JPEG (max. 10MB)</p>
                      </div>
                      <input
                        id="image"
                        type="file"
                        accept="image/*"
                        className="sr-only"
                        onChange={handleImageChange}
                        required
                      />
                      <button
                        type="button"
                        className="btn btn-secondary"
                        onClick={() => document.getElementById("image")?.click()}
                      >
                        Select Image
                      </button>
                    </div>
                  )}
                </div>
              </div>

              <div className="form-group">
                <div className="flex items-center justify-between">
                  <label className="label" htmlFor="location">
                    Location
                  </label>
                  <button type="button" className="btn btn-secondary btn-sm" onClick={handleGetLocation}>
                    <MapPin style={{ width: "0.75rem", height: "0.75rem", marginRight: "0.25rem" }} />
                    Get Current Location
                  </button>
                </div>
                <input
                  id="location"
                  className="input"
                  placeholder="Enter address or coordinates"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  required
                />
              </div>

              <div className="form-group">
                <label className="label" htmlFor="description">
                  Description (Optional)
                </label>
                <textarea
                  id="description"
                  className="textarea"
                  placeholder="Describe the type and amount of waste"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  rows={3}
                />
              </div>
              <div className="form-group">
                <label className="label" htmlFor="category">
                  Waste Category
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    className={`btn ${category === "E-Waste" ? "btn-primary" : "btn-outline"}`}
                    onClick={() => setCategory("E-Waste")}
                  >
                    E-Waste
                  </button>
                  <button
                    type="button"
                    className={`btn ${category === "General Waste" ? "btn-primary" : "btn-outline"}`}
                    onClick={() => setCategory("General Waste")}
                  >
                    General Waste
                  </button>
                </div>
              </div>
            </div>
            <div className="card-footer">
              <button className="btn btn-primary btn-block" disabled={isLoading}>
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 animate-spin" style={{ width: "1rem", height: "1rem" }} />
                    Submitting...
                  </>
                ) : (
                  "Submit Report"
                )}
              </button>
            </div>
          </form>
        </div>
      </main>
    </div>
  )
}

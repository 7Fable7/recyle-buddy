import Link from "next/link"
import { ArrowRight, Recycle, Calendar, MapPin, ImageIcon } from "lucide-react"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="header">
        <Link href="/" className="header-logo">
          <Recycle className="text-primary" style={{ width: "1.5rem", height: "1.5rem" }} />
          <span className="text-lg">Recycle Buddy</span>
        </Link>
        <nav className="header-nav">
          <Link href="/about" className="header-nav-link">
            About
          </Link>
          <Link href="/how-it-works" className="header-nav-link">
            How It Works
          </Link>
          <Link href="/contact" className="header-nav-link">
            Contact
          </Link>
        </nav>
        <div className="flex gap-2 ml-4">
          <Link href="/login">
            <button className="btn btn-outline btn-sm">Log In</button>
          </Link>
          <Link href="/signup">
            <button className="btn btn-primary btn-sm">Sign Up</button>
          </Link>
        </div>
      </header>
      <main className="flex-1">
        <section className="py-12 bg-green-50" style={{ padding: "3rem 0" }}>
          <div className="container">
            <div className="grid md:grid-cols-2 gap-6 items-center">
              <div className="flex flex-col justify-center gap-4">
                <div className="space-y-2">
                  <h1 className="text-3xl font-bold">Simplify Waste Collection & Recycling</h1>
                  <p className="text-gray-500" style={{ maxWidth: "600px" }}>
                    Upload a picture of your waste, share your location, and we'll connect you with local waste
                    management facilities for scheduled pickups.
                  </p>
                </div>
                <div className="flex flex-col sm:flex-row gap-2">
                  <Link href="/upload">
                    <button className="btn btn-primary">
                      Report Waste
                      <ArrowRight className="ml-2" style={{ width: "1rem", height: "1rem" }} />
                    </button>
                  </Link>
                  <Link href="/facilities">
                    <button className="btn btn-outline">For Waste Facilities</button>
                  </Link>
                </div>
              </div>
              <div style={{ maxWidth: "500px", margin: "0 auto", width: "100%" }}>
                <div className="aspect-video rounded overflow-hidden bg-gray-100">
                  <img
                    src="/placeholder.svg?height=500&width=800"
                    alt="Waste management illustration"
                    style={{ objectFit: "cover", width: "100%", height: "100%" }}
                  />
                </div>
              </div>
            </div>
          </div>
        </section>
        <section style={{ padding: "3rem 0" }}>
          <div className="container">
            <div className="flex flex-col items-center justify-center gap-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold">How It Works</h2>
                <p className="text-gray-500" style={{ maxWidth: "900px" }}>
                  Our platform connects waste generators with waste management facilities for efficient collection and
                  recycling.
                </p>
              </div>
            </div>
            <div className="grid md:grid-cols-3 gap-6 py-12" style={{ maxWidth: "1200px", margin: "0 auto" }}>
              <div className="card p-6">
                <div
                  className="flex items-center justify-center rounded-full bg-green-50"
                  style={{ width: "3rem", height: "3rem" }}
                >
                  <ImageIcon className="text-primary" style={{ width: "1.5rem", height: "1.5rem" }} />
                </div>
                <div className="mt-4 space-y-2">
                  <h3 className="text-xl font-bold">Upload Photo</h3>
                  <p className="text-gray-500">
                    Take a picture of the waste that needs to be collected and upload it to our platform.
                  </p>
                </div>
              </div>
              <div className="card p-6">
                <div
                  className="flex items-center justify-center rounded-full bg-green-50"
                  style={{ width: "3rem", height: "3rem" }}
                >
                  <MapPin className="text-primary" style={{ width: "1.5rem", height: "1.5rem" }} />
                </div>
                <div className="mt-4 space-y-2">
                  <h3 className="text-xl font-bold">Share Location</h3>
                  <p className="text-gray-500">
                    Provide your location so waste management facilities know where to pick up the waste.
                  </p>
                </div>
              </div>
              <div className="card p-6">
                <div
                  className="flex items-center justify-center rounded-full bg-green-50"
                  style={{ width: "3rem", height: "3rem" }}
                >
                  <Calendar className="text-primary" style={{ width: "1.5rem", height: "1.5rem" }} />
                </div>
                <div className="mt-4 space-y-2">
                  <h3 className="text-xl font-bold">Schedule Pickup</h3>
                  <p className="text-gray-500">
                    Waste management facilities will review your request and schedule a convenient pickup time.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer className="flex flex-col sm:flex-row gap-2 py-6 border-t px-4">
        <p className="text-xs text-gray-500">© 2024 Recycle Buddy. All rights reserved.</p>
        <nav className="sm:ml-auto flex gap-4">
          <Link href="/terms" className="text-xs hover:underline">
            Terms of Service
          </Link>
          <Link href="/privacy" className="text-xs hover:underline">
            Privacy
          </Link>
        </nav>
      </footer>
    </div>
  )
}

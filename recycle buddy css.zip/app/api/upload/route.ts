import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const file = formData.get("file") as File

    if (!file) {
      return NextResponse.json({ error: "No file uploaded" }, { status: 400 })
    }

    // In a real implementation with Vercel Blob
    // const blob = await put(file.name, file, {
    //   access: 'public',
    // })

    // For demo purposes without actual blob storage:
    const mockBlobUrl = `https://example.com/images/${Date.now()}-${file.name}`

    return NextResponse.json({
      url: mockBlobUrl,
      success: true,
    })
  } catch (error) {
    console.error("Upload error:", error)
    return NextResponse.json({ error: "Upload failed" }, { status: 500 })
  }
}

import { type NextRequest, NextResponse } from "next/server"

// POST /api/auth/login - Handle login requests
export async function POST(request: NextRequest) {
  try {
    const { email, password } = await request.json()

    // Validate credentials
    if (!email || !password) {
      return NextResponse.json({ error: "Email and password are required" }, { status: 400 })
    }

    // In a real implementation, you would validate against your database
    // For demo purposes, accepting any valid email/password combination
    if (email.includes("@") && password.length >= 6) {
      // Generate a mock token
      const token = Buffer.from(`${email}:${Date.now()}`).toString("base64")

      return NextResponse.json({
        success: true,
        token,
        user: {
          id: "user1",
          email,
          name: email.split("@")[0],
        },
      })
    } else {
      return NextResponse.json({ error: "Invalid credentials" }, { status: 401 })
    }
  } catch (error) {
    console.error("Login error:", error)
    return NextResponse.json({ error: "Authentication failed" }, { status: 500 })
  }
}

import { type NextRequest, NextResponse } from "next/server"

// GET /api/reports/:id - Get a specific report
export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const id = params.id

    // In a real implementation, you would fetch the report from your database
    // For demo purposes, returning mock data
    if (id === "1") {
      return NextResponse.json({
        id: "1",
        imageUrl: "/placeholder.svg?height=200&width=300",
        location: "123 Main St, Anytown",
        description: "Plastic waste and cardboard boxes",
        category: "General Waste",
        status: "scheduled",
        date: "2024-05-05",
        time: "10:00 AM - 12:00 PM",
        facility: "Green Recycling Co.",
      })
    } else if (id === "2") {
      return NextResponse.json({
        id: "2",
        imageUrl: "/placeholder.svg?height=200&width=300",
        location: "456 Oak Ave, Somewhere",
        description: "Electronic waste",
        category: "E-Waste",
        status: "pending",
      })
    } else {
      return NextResponse.json({ error: "Report not found" }, { status: 404 })
    }
  } catch (error) {
    console.error("Error fetching report:", error)
    return NextResponse.json({ error: "Failed to fetch report" }, { status: 500 })
  }
}

// PATCH /api/reports/:id - Update a report (e.g., schedule pickup)
export async function PATCH(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const id = params.id
    const data = await request.json()

    // In a real implementation, you would update the report in your database
    // For demo purposes, just return success

    return NextResponse.json({
      id,
      ...data,
      updated: true,
      updatedAt: new Date().toISOString(),
    })
  } catch (error) {
    console.error("Error updating report:", error)
    return NextResponse.json({ error: "Failed to update report" }, { status: 500 })
  }
}

// DELETE /api/reports/:id - Delete a report
export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const id = params.id

    // In a real implementation, you would delete the report from your database
    // For demo purposes, just return success

    return NextResponse.json({ success: true, id })
  } catch (error) {
    console.error("Error deleting report:", error)
    return NextResponse.json({ error: "Failed to delete report" }, { status: 500 })
  }
}

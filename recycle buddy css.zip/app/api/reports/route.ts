import { type NextRequest, NextResponse } from "next/server"

// GET /api/reports - Get all reports or filtered by user ID
export async function GET(request: NextRequest) {
  try {
    const userId = request.nextUrl.searchParams.get("userId")

    // In a real implementation, you would fetch reports from your database
    // For demo purposes, we're returning mock data
    const reports = [
      {
        id: "1",
        imageUrl: "/placeholder.svg?height=200&width=300",
        location: "123 Main St, Anytown",
        description: "Plastic waste and cardboard boxes",
        category: "General Waste",
        status: "scheduled",
        userId: "user1",
        date: "2024-05-05",
        time: "10:00 AM - 12:00 PM",
        facility: "Green Recycling Co.",
      },
      {
        id: "2",
        imageUrl: "/placeholder.svg?height=200&width=300",
        location: "456 Oak Ave, Somewhere",
        description: "Electronic waste",
        category: "E-Waste",
        status: "pending",
        userId: "user1",
      },
    ]

    // Filter by user ID if provided
    const filteredReports = userId ? reports.filter((r) => r.userId === userId) : reports

    return NextResponse.json(filteredReports)
  } catch (error) {
    console.error("Error fetching reports:", error)
    return NextResponse.json({ error: "Failed to fetch reports" }, { status: 500 })
  }
}

// POST /api/reports - Create a new report
export async function POST(request: NextRequest) {
  try {
    const data = await request.json()

    // Validate required fields
    if (!data.location || !data.category) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // In a real implementation, you would save to your database
    // and upload the image to blob storage

    // Mock response with generated ID
    const newReport = {
      id: Math.floor(Math.random() * 1000).toString(),
      ...data,
      status: "pending",
      createdAt: new Date().toISOString(),
    }

    return NextResponse.json(newReport, { status: 201 })
  } catch (error) {
    console.error("Error creating report:", error)
    return NextResponse.json({ error: "Failed to create report" }, { status: 500 })
  }
}

import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Recycle, Code, Database, FileJson, ImageIcon, RefreshCw } from "lucide-react"

export default function AndroidIntegrationPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="px-4 lg:px-6 h-16 flex items-center border-b">
        <Link href="/" className="flex items-center gap-2 font-semibold">
          <Recycle className="h-6 w-6 text-green-600" />
          <span className="text-lg">WasteConnect</span>
        </Link>
        <nav className="ml-auto flex gap-4 sm:gap-6">
          <Link href="/docs" className="text-sm font-medium hover:underline underline-offset-4">
            Documentation
          </Link>
          <Link href="/" className="text-sm font-medium hover:underline underline-offset-4">
            Home
          </Link>
        </nav>
      </header>
      <main className="flex-1 p-4 md:p-6 lg:p-8">
        <div className="max-w-4xl mx-auto space-y-8">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Android App Integration Guide</h1>
            <p className="text-gray-500 mt-2">Learn how to connect your Android app with the WasteConnect platform</p>
          </div>

          <Tabs defaultValue="setup" className="w-full">
            <TabsList className="grid grid-cols-3 md:grid-cols-5">
              <TabsTrigger value="setup">Setup</TabsTrigger>
              <TabsTrigger value="auth">Authentication</TabsTrigger>
              <TabsTrigger value="reports">Reports API</TabsTrigger>
              <TabsTrigger value="images">Image Upload</TabsTrigger>
              <TabsTrigger value="sync">Data Sync</TabsTrigger>
            </TabsList>

            <TabsContent value="setup" className="mt-6 space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Database className="h-5 w-5" />
                    Setting Up Your Android App
                  </CardTitle>
                  <CardDescription>
                    Follow these steps to connect your Android app to the WasteConnect platform
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <h3 className="font-semibold text-lg">1. Create an API Client</h3>
                    <p className="text-gray-600">Create a Retrofit API client to communicate with our API endpoints:</p>
                    <pre className="bg-gray-100 p-4 rounded-md overflow-x-auto text-sm">
                      {`// RetrofitClient.kt
object RetrofitClient {
    private const val BASE_URL = "https://your-wasteconnect-app.vercel.app/api/"
    
    private val client = OkHttpClient.Builder()
        .addInterceptor(AuthInterceptor())
        .build()
        
    val instance: Retrofit by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .client(client)
            .build()
    }
}`}
                    </pre>
                  </div>

                  <div className="space-y-2">
                    <h3 className="font-semibold text-lg">2. Define API Interfaces</h3>
                    <p className="text-gray-600">Create API service interfaces:</p>
                    <pre className="bg-gray-100 p-4 rounded-md overflow-x-auto text-sm">
                      {`// WasteConnectApi.kt
interface WasteConnectApi {
    @POST("auth")
    suspend fun login(@Body loginRequest: LoginRequest): Response<AuthResponse>
    
    @GET("reports")
    suspend fun getReports(@Query("userId") userId: String? = null): Response<List<WasteReport>>
    
    @POST("reports")
    suspend fun createReport(@Body report: WasteReport): Response<WasteReport>
    
    @Multipart
    @POST("upload")
    suspend fun uploadImage(
        @Part image: MultipartBody.Part
    ): Response<UploadResponse>
}`}
                    </pre>
                  </div>

                  <div className="space-y-2">
                    <h3 className="font-semibold text-lg">3. Create Data Models</h3>
                    <p className="text-gray-600">Define data models to match the API responses:</p>
                    <pre className="bg-gray-100 p-4 rounded-md overflow-x-auto text-sm">
                      {`// WasteReport.kt
data class WasteReport(
    val id: String? = null,
    val imageUrl: String? = null,
    val location: String,
    val description: String? = null,
    val category: String,
    val status: String = "pending",
    val date: String? = null,
    val time: String? = null,
    val facility: String? = null,
    val userId: String? = null
)

// AuthResponse.kt
data class AuthResponse(
    val success: Boolean,
    val token: String,
    val user: User
)

// User.kt
data class User(
    val id: String,
    val email: String,
    val name: String
)`}
                    </pre>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="auth" className="mt-6 space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Code className="h-5 w-5" />
                    Authentication Implementation
                  </CardTitle>
                  <CardDescription>Implementing authentication in your Android app</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <h3 className="font-semibold text-lg">1. Create Auth Interceptor</h3>
                    <p className="text-gray-600">Add authentication token to your requests:</p>
                    <pre className="bg-gray-100 p-4 rounded-md overflow-x-auto text-sm">
                      {`// AuthInterceptor.kt
class AuthInterceptor : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request()
        val token = SharedPrefsManager.getToken()
        
        return if (token != null) {
            val newRequest = request.newBuilder()
                .header("Authorization", "Bearer $token")
                .build()
            chain.proceed(newRequest)
        } else {
            chain.proceed(request)
        }
    }
}`}
                    </pre>
                  </div>

                  <div className="space-y-2">
                    <h3 className="font-semibold text-lg">2. Implement Login Flow</h3>
                    <p className="text-gray-600">Create a ViewModel for authentication:</p>
                    <pre className="bg-gray-100 p-4 rounded-md overflow-x-auto text-sm">
                      {`// AuthViewModel.kt
class AuthViewModel(private val repository: AuthRepository) : ViewModel() {
    private val _loginResult = MutableLiveData<Resource<AuthResponse>>()
    val loginResult: LiveData<Resource<AuthResponse>> = _loginResult
    
    fun login(email: String, password: String) = viewModelScope.launch {
        _loginResult.value = Resource.Loading()
        try {
            val response = repository.login(LoginRequest(email, password))
            if (response.isSuccessful && response.body() != null) {
                val authResponse = response.body()!!
                SharedPrefsManager.saveToken(authResponse.token)
                SharedPrefsManager.saveUser(authResponse.user)
                _loginResult.value = Resource.Success(authResponse)
            } else {
                _loginResult.value = Resource.Error("Authentication failed")
            }
        } catch (e: Exception) {
            _loginResult.value = Resource.Error(e.message ?: "Unknown error")
        }
    }
}`}
                    </pre>
                  </div>

                  <div className="space-y-2">
                    <h3 className="font-semibold text-lg">3. Save User Session</h3>
                    <p className="text-gray-600">Create a SharedPrefs manager for user session:</p>
                    <pre className="bg-gray-100 p-4 rounded-md overflow-x-auto text-sm">
                      {`// SharedPrefsManager.kt
object SharedPrefsManager {
    private const val PREFS_NAME = "WasteConnectPrefs"
    private const val KEY_TOKEN = "auth_token"
    private const val KEY_USER_ID = "user_id"
    private const val KEY_USER_EMAIL = "user_email"
    private const val KEY_USER_NAME = "user_name"
    
    private fun getSharedPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }
    
    fun saveToken(token: String) {
        getSharedPrefs(WasteConnectApp.instance).edit().putString(KEY_TOKEN, token).apply()
    }
    
    fun getToken(): String? {
        return getSharedPrefs(WasteConnectApp.instance).getString(KEY_TOKEN, null)
    }
    
    fun saveUser(user: User) {
        getSharedPrefs(WasteConnectApp.instance).edit().apply {
            putString(KEY_USER_ID, user.id)
            putString(KEY_USER_EMAIL, user.email)
            putString(KEY_USER_NAME, user.name)
            apply()
        }
    }
    
    fun clearSession() {
        getSharedPrefs(WasteConnectApp.instance).edit().clear().apply()
    }
}`}
                    </pre>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="reports" className="mt-6 space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileJson className="h-5 w-5" />
                    Reports API Integration
                  </CardTitle>
                  <CardDescription>Implement report creation and fetching in your Android app</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <h3 className="font-semibold text-lg">1. Create Repository</h3>
                    <p className="text-gray-600">Implement a repository for report operations:</p>
                    <pre className="bg-gray-100 p-4 rounded-md overflow-x-auto text-sm">
                      {`// ReportRepository.kt
class ReportRepository {
    private val api = RetrofitClient.instance.create(WasteConnectApi::class.java)
    
    suspend fun getReports(userId: String? = null): Response<List<WasteReport>> {
        return api.getReports(userId)
    }
    
    suspend fun createReport(report: WasteReport): Response<WasteReport> {
        return api.createReport(report)
    }
    
    suspend fun getReportById(id: String): Response<WasteReport> {
        return api.getReportById(id)
    }
    
    suspend fun uploadImage(imageFile: File): Response<UploadResponse> {
        val requestFile = imageFile.asRequestBody("image/*".toMediaTypeOrNull())
        val body = MultipartBody.Part.createFormData("file", imageFile.name, requestFile)
        return api.uploadImage(body)
    }
}`}
                    </pre>
                  </div>

                  <div className="space-y-2">
                    <h3 className="font-semibold text-lg">2. Create ViewModel</h3>
                    <p className="text-gray-600">Implement ViewModel for reports functionality:</p>
                    <pre className="bg-gray-100 p-4 rounded-md overflow-x-auto text-sm">
                      {`// ReportViewModel.kt
class ReportViewModel(private val repository: ReportRepository) : ViewModel() {
    private val _reports = MutableLiveData<Resource<List<WasteReport>>>()
    val reports: LiveData<Resource<List<WasteReport>>> = _reports
    
    private val _createReportResult = MutableLiveData<Resource<WasteReport>>()
    val createReportResult: LiveData<Resource<WasteReport>> = _createReportResult
    
    private val _reportDetails = MutableLiveData<Resource<WasteReport>>()
    val reportDetails: LiveData<Resource<WasteReport>> = _reportDetails
    
    fun getReports(userId: String? = null) = viewModelScope.launch {
        _reports.value = Resource.Loading()
        try {
            val response = repository.getReports(userId)
            if (response.isSuccessful) {
                _reports.value = Resource.Success(response.body() ?: emptyList())
            } else {
                _reports.value = Resource.Error("Failed to fetch reports")
            }
        } catch (e: Exception) {
            _reports.value = Resource.Error(e.message ?: "Unknown error")
        }
    }
    
    fun createReport(
        imageUrl: String?, 
        location: String,
        description: String?,
        category: String
    ) = viewModelScope.launch {
        _createReportResult.value = Resource.Loading()
        
        try {
            val userId = SharedPrefsManager.getUserId()
            val report = WasteReport(
                imageUrl = imageUrl,
                location = location,
                description = description,
                category = category,
                userId = userId
            )
            
            val response = repository.createReport(report)
            if (response.isSuccessful && response.body() != null) {
                _createReportResult.value = Resource.Success(response.body()!!)
            } else {
                _createReportResult.value = Resource.Error("Failed to create report")
            }
        } catch (e: Exception) {
            _createReportResult.value = Resource.Error(e.message ?: "Unknown error")
        }
    }
    
    fun getReportDetails(id: String) = viewModelScope.launch {
        _reportDetails.value = Resource.Loading()
        try {
            val response = repository.getReportById(id)
            if (response.isSuccessful && response.body() != null) {
                _reportDetails.value = Resource.Success(response.body()!!)
            } else {
                _reportDetails.value = Resource.Error("Report not found")
            }
        } catch (e: Exception) {
            _reportDetails.value = Resource.Error(e.message ?: "Unknown error")
        }
    }
}`}
                    </pre>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="images" className="mt-6 space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <ImageIcon className="h-5 w-5" />
                    Image Upload Implementation
                  </CardTitle>
                  <CardDescription>Handle image uploads in your Android app</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <h3 className="font-semibold text-lg">1. Add Upload Functionality</h3>
                    <p className="text-gray-600">Implement image selection and upload feature:</p>
                    <pre className="bg-gray-100 p-4 rounded-md overflow-x-auto text-sm">
                      {`// CreateReportViewModel.kt
class CreateReportViewModel(private val repository: ReportRepository) : ViewModel() {
    private val _uploadResult = MutableLiveData<Resource<UploadResponse>>()
    val uploadResult: LiveData<Resource<UploadResponse>> = _uploadResult
    
    private val _createReportResult = MutableLiveData<Resource<WasteReport>>()
    val createReportResult: LiveData<Resource<WasteReport>> = _createReportResult
    
    fun uploadImage(imageFile: File) = viewModelScope.launch {
        _uploadResult.value = Resource.Loading()
        try {
            val response = repository.uploadImage(imageFile)
            if (response.isSuccessful && response.body() != null) {
                _uploadResult.value = Resource.Success(response.body()!!)
            } else {
                _uploadResult.value = Resource.Error("Upload failed")
            }
        } catch (e: Exception) {
            _uploadResult.value = Resource.Error(e.message ?: "Unknown error")
        }
    }
    
    fun createReportWithImage(
        imageFile: File?,
        location: String,
        description: String?,
        category: String
    ) = viewModelScope.launch {
        // First upload the image if available
        if (imageFile != null) {
            _uploadResult.value = Resource.Loading()
            try {
                val uploadResponse = repository.uploadImage(imageFile)
                if (uploadResponse.isSuccessful && uploadResponse.body() != null) {
                    val imageUrl = uploadResponse.body()!!.url
                    // Then create the report with the image URL
                    createReport(imageUrl, location, description, category)
                } else {
                    _uploadResult.value = Resource.Error("Image upload failed")
                }
            } catch (e: Exception) {
                _uploadResult.value = Resource.Error(e.message ?: "Unknown error")
            }
        } else {
            // Create report without image
            createReport(null, location, description, category)
        }
    }
    
    private fun createReport(
        imageUrl: String?,
        location: String,
        description: String?,
        category: String
    ) = viewModelScope.launch {
        _createReportResult.value = Resource.Loading()
        
        try {
            val userId = SharedPrefsManager.getUserId()
            val report = WasteReport(
                imageUrl = imageUrl,
                location = location,
                description = description,
                category = category,
                userId = userId
            )
            
            val response = repository.createReport(report)
            if (response.isSuccessful && response.body() != null) {
                _createReportResult.value = Resource.Success(response.body()!!)
            } else {
                _createReportResult.value = Resource.Error("Failed to create report")
            }
        } catch (e: Exception) {
            _createReportResult.value = Resource.Error(e.message ?: "Unknown error")
        }
    }
}`}
                    </pre>
                  </div>

                  <div className="space-y-2">
                    <h3 className="font-semibold text-lg">2. Implement Image Capture</h3>
                    <p className="text-gray-600">Create an Activity to capture or select an image:</p>
                    <pre className="bg-gray-100 p-4 rounded-md overflow-x-auto text-sm">
                      {`// CreateReportActivity.kt - Image selection part
private fun selectImage() {
    val options = arrayOf("Take Photo", "Choose from Gallery", "Cancel")
    val builder = AlertDialog.Builder(this)
    builder.setTitle("Add Photo")
    builder.setItems(options) { dialog, item ->
        when (options[item]) {
            "Take Photo" -> {
                if (checkCameraPermission()) {
                    takePhotoFromCamera()
                } else {
                    requestCameraPermission()
                }
            }
            "Choose from Gallery" -> {
                if (checkStoragePermission()) {
                    choosePhotoFromGallery()
                } else {
                    requestStoragePermission()
                }
            }
            "Cancel" -> dialog.dismiss()
        }
    }
    builder.show()
}

// Permission handling methods...

private fun takePhotoFromCamera() {
    val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
    startActivityForResult(intent, REQUEST_CAMERA)
}

private fun choosePhotoFromGallery() {
    val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
    startActivityForResult(intent, SELECT_FROM_GALLERY)
}

override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
    super.onActivityResult(requestCode, resultCode, data)
    if (resultCode == Activity.RESULT_OK) {
        when (requestCode) {
            REQUEST_CAMERA -> {
                val thumbnail = data?.extras?.get("data") as Bitmap
                imageFile = saveBitmapToFile(thumbnail)
                binding.imagePreview.setImageBitmap(thumbnail)
                binding.imagePreview.visibility = View.VISIBLE
            }
            SELECT_FROM_GALLERY -> {
                val selectedImage = data?.data
                imageFile = getFileFromUri(selectedImage!!)
                binding.imagePreview.setImageURI(selectedImage)
                binding.imagePreview.visibility = View.VISIBLE
            }
        }
    }
}`}
                    </pre>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="sync" className="mt-6 space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <RefreshCw className="h-5 w-5" />
                    Data Synchronization
                  </CardTitle>
                  <CardDescription>Keep your Android app in sync with the platform</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <h3 className="font-semibold text-lg">1. Implement Background Sync</h3>
                    <p className="text-gray-600">Create a WorkManager for periodic syncing:</p>
                    <pre className="bg-gray-100 p-4 rounded-md overflow-x-auto text-sm">
                      {`// SyncWorker.kt
class SyncWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    private val repository = ReportRepository()
    
    override suspend fun doWork(): Result {
        try {
            val userId = SharedPrefsManager.getUserId() ?: return Result.failure()
            
            // Fetch latest reports from server
            val response = repository.getReports(userId)
            if (response.isSuccessful) {
                val reports = response.body() ?: emptyList()
                // Update local database
                AppDatabase.getInstance(applicationContext).reportDao().insertAll(reports)
                return Result.success()
            }
            return Result.retry()
        } catch (e: Exception) {
            return Result.failure()
        }
    }
}`}
                    </pre>
                  </div>

                  <div className="space-y-2">
                    <h3 className="font-semibold text-lg">2. Schedule Periodic Sync</h3>
                    <p className="text-gray-600">Setup background sync when app starts:</p>
                    <pre className="bg-gray-100 p-4 rounded-md overflow-x-auto text-sm">
                      {`// WasteConnectApp.kt - Application class
override fun onCreate() {
    super.onCreate()
    instance = this
    setupWorkManager()
}

private fun setupWorkManager() {
    val constraints = Constraints.Builder()
        .setRequiredNetworkType(NetworkType.CONNECTED)
        .build()
    
    val syncRequest = PeriodicWorkRequestBuilder<SyncWorker>(15, TimeUnit.MINUTES)
        .setConstraints(constraints)
        .build()
    
    WorkManager.getInstance(this).enqueueUniquePeriodicWork(
        "WasteConnectSync",
        ExistingPeriodicWorkPolicy.KEEP,
        syncRequest
    )
}`}
                    </pre>
                  </div>

                  <div className="space-y-2">
                    <h3 className="font-semibold text-lg">3. Implement Room Database</h3>
                    <p className="text-gray-600">For offline access and data caching:</p>
                    <pre className="bg-gray-100 p-4 rounded-md overflow-x-auto text-sm">
                      {`// WasteReportEntity.kt
@Entity(tableName = "waste_reports")
data class WasteReportEntity(
    @PrimaryKey
    val id: String,
    val imageUrl: String?,
    val location: String,
    val description: String?,
    val category: String,
    val status: String,
    val date: String?,
    val time: String?,
    val facility: String?,
    val userId: String?,
    val syncedWithServer: Boolean = true,
    val lastUpdated: Long = System.currentTimeMillis()
)

// ReportDao.kt
@Dao
interface ReportDao {
    @Query("SELECT * FROM waste_reports WHERE userId = :userId ORDER BY lastUpdated DESC")
    fun getReportsByUser(userId: String): LiveData<List<WasteReportEntity>>
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(report: WasteReportEntity)
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(reports: List<WasteReportEntity>)
    
    @Query("SELECT * FROM waste_reports WHERE syncedWithServer = 0")
    suspend fun getUnsyncedReports(): List<WasteReportEntity>
    
    @Query("UPDATE waste_reports SET syncedWithServer = 1 WHERE id = :reportId")
    suspend fun markAsSynced(reportId: String)
}`}
                    </pre>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}

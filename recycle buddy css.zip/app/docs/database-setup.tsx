import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Recycle, Database, Table, Lock } from "lucide-react"

export default function DatabaseSetupPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="px-4 lg:px-6 h-16 flex items-center border-b">
        <Link href="/" className="flex items-center gap-2 font-semibold">
          <Recycle className="h-6 w-6 text-green-600" />
          <span className="text-lg">WasteConnect</span>
        </Link>
        <nav className="ml-auto flex gap-4 sm:gap-6">
          <Link href="/docs" className="text-sm font-medium hover:underline underline-offset-4">
            Documentation
          </Link>
          <Link href="/" className="text-sm font-medium hover:underline underline-offset-4">
            Home
          </Link>
        </nav>
      </header>
      <main className="flex-1 p-4 md:p-6 lg:p-8">
        <div className="max-w-4xl mx-auto space-y-8">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Database Integration Guide</h1>
            <p className="text-gray-500 mt-2">
              Learn how to integrate Supabase database with WasteConnect
            </p>
          </div>

          <Tabs defaultValue="setup" className="w-full">
            <TabsList className="grid grid-cols-2 md:grid-cols-4">
              <TabsTrigger value="setup">Initial Setup</TabsTrigger>
              <TabsTrigger value="schema">Database Schema</TabsTrigger>
              <TabsTrigger value="auth">Authentication</TabsTrigger>
              <TabsTrigger value="queries">Common Queries</TabsTrigger>
            </TabsList>
            
            <TabsContent value="setup" className="mt-6 space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Database className="h-5 w-5" /> 
                    Setting Up Supabase
                  </CardTitle>
                  <CardDescription>
                    Follow these steps to set up Supabase integration for your WasteConnect app
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <h3 className="font-semibold text-lg">1. Create a Supabase Project</h3>
                    <p className="text-gray-600">Visit <a href="https://supabase.com" target="_blank" rel="noopener noreferrer" className="text-green-600 hover:underline">Supabase.com</a> and create a new project.</p>
                    <ul className="list-disc pl-6 space-y-1 text-gray-600">
                      <li>Sign up for a Supabase account if you don't already have one</li>
                      <li>Click "New Project" and provide a name for your project</li>
                      <li>Choose a database password and region</li>
                      <li>Click "Create new project"</li>
                    </ul>
                  </div>
                  
                  <div className="space-y-2">
                    <h3 className="font-semibold text-lg">2. Install Supabase Client</h3>
                    <p className="text-gray-600">Install the Supabase JavaScript client in your Next.js project:</p>
                    <pre className="bg-gray-100 p-4 rounded-md overflow-x-auto text-sm">
                      npm install @supabase/supabase-js
                    </pre>
                  </div>
                  
                  <div className="space-y-2">
                    <h3 className="font-semibold text-lg">3. Setup Environment Variables</h3>
                    <p className="text-gray-600">Create a .env.local file with your Supabase credentials:</p>
                    <pre className="bg-gray-100 p-4 rounded-md overflow-x-auto text-sm">
{`# .env.local
NEXT_PUBLIC_SUPABASE_URL=https://your-project-url.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key`}
                    </pre>
                    <p className="text-gray-600 mt-2">These values can be found in your Supabase dashboard under Project Settings → API.</p>
                  </div>
                  
                  <div className="space-y-2">
                    <h3 className="font-semibold text-lg">4. Create a Supabase Client</h3>
                    <p className="text-gray-600">Create a file to initialize your Supabase client:</p>
                    <pre className="bg-gray-100 p-4 rounded-md overflow-x-auto text-sm">
{`// lib/supabase.ts
import { createClient } from '@supabase/supabase-js'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL as string
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY as string

export const supabase = createClient(supabaseUrl, supabaseAnonKey)`}
                    </pre>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="schema" className="mt-6 space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Table className="h-5 w-5" /> 
                    Database Schema
                  </CardTitle>
                  <CardDescription>
                    Set up the necessary tables for your WasteConnect application
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <h3 className="font-semibold text-lg">1. Create Tables Using SQL</h3>
                    <p className="text-gray-600">Run the following SQL in the Supabase SQL editor to create your tables:</p>
                    <pre className="bg-gray-100 p-4 rounded-md overflow-x-auto text-sm">
{`-- Create users table (extends Supabase auth.users)
CREATE TABLE public.profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    email TEXT NOT NULL,
    full_name TEXT,
    address TEXT,
    phone TEXT,
    avatar_url TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL
);

-- Create waste reports table
CREATE TABLE public.waste_reports (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
    image_url TEXT,
    location TEXT NOT NULL,
    coordinates TEXT,
    description TEXT,
    category TEXT NOT NULL,
    status TEXT DEFAULT 'pending' NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL
);

-- Create facilities table
CREATE TABLE public.facilities (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    phone TEXT,
    address TEXT NOT NULL,
    description TEXT,
    service_area NUMERIC,
    waste_types TEXT[],
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL
);

-- Create pickups table
CREATE TABLE public.pickups (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    report_id UUID REFERENCES public.waste_reports(id) ON DELETE CASCADE,
    facility_id UUID REFERENCES public.facilities(id),
    scheduled_date DATE NOT NULL,
    time_from TIME NOT NULL,
    time_to TIME NOT NULL,
    vehicle_type TEXT,
    status TEXT DEFAULT 'scheduled' NOT NULL,
    notes TEXT,
    completion_photo_url TEXT,
    completion_notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
    completed_at TIMESTAMP WITH TIME ZONE
);

-- Add RLS policies
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.waste_reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.facilities ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pickups ENABLE ROW LEVEL SECURITY;

-- Create profile trigger
CREATE OR REPLACE FUNCTION public.handle_new_user() 
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name)
  VALUES (new.id, new.email, new.raw_user_meta_data->>'full_name');
  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE PROCEDURE public.handle_new_user();`}
                    </pre>
                  </div>
                  
                  <div className="space-y-2">
                    <h3 className="font-semibold text-lg">2. Add Row Level Security Policies</h3>
                    <p className="text-gray-600">Add policies to control access to your tables:</p>
                    <pre className="bg-gray-100 p-4 rounded-md overflow-x-auto text-sm">
{`-- Profiles policies
CREATE POLICY "Users can view their own profile"
ON public.profiles FOR SELECT
USING (auth.uid() = id);

CREATE POLICY "Users can update their own profile"
ON public.profiles FOR UPDATE
USING (auth.uid() = id);

-- Waste reports policies
CREATE POLICY "Anyone can create waste reports"
ON public.waste_reports FOR INSERT
WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Users can view their own reports"
ON public.waste_reports FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Facilities can view all reports"
ON public.waste_reports FOR SELECT
USING (auth.uid() IN (SELECT id FROM public.facilities));

-- Pickups policies
CREATE POLICY "Facilities can create pickups"
ON public.pickups FOR INSERT
WITH CHECK (auth.uid() = facility_id);

CREATE POLICY "Users can view pickups for their reports"
ON public.pickups FOR SELECT
USING (auth.uid() IN (
  SELECT user_id FROM public.waste_reports WHERE id = report_id
));

CREATE POLICY "Facilities can view their scheduled pickups"
ON public.pickups FOR SELECT
USING (auth.uid() = facility_id);`}
                    </pre>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="auth" className="mt-6 space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Lock className="h-5 w-5" /> 
                    Authentication Setup
                  </CardTitle>
                  <CardDescription>
                    Implement authentication using Supabase
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <h3 className="font-semibold text-lg">1. Create Auth Helper Functions</h3>
                    <p className="text-gray-600">Create a file for authentication functions:</p>
                    <pre className="bg-gray-100 p-4 rounded-md overflow-x-auto text-sm">
{`// lib/auth.ts
import { supabase } from './supabase'

export async function signUp(email: string, password: string, fullName: string) {
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: {
        full_name: fullName,
      },
    },
  })
  
  return { data, error }
}

export async function signIn(email: string, password: string) {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  })
  
  return { data, error }
}

export async function signOut() {
  const { error } = await supabase.auth.signOut()
  return { error }
}

export async function getSession() {
  const { data: { session }, error } = await supabase.auth.getSession()
  return { session, error }
}

export async function getUserProfile() {
  const { data: { session }, error: sessionError } = await supabase.auth.getSession()
  
  if (sessionError || !session) {
    return { profile: null, error: sessionError || new Error("No session found") }
  }
  
  const { data: profile, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', session.user.id)
    .single()
  
  return { profile, error }
}`}
                    </pre>
                  </div>
                  
                  <div className="space-y-2">
                    <h3 className="font-semibold text-lg">2. Create Auth Context</h3>
                    <p className="text-gray-600">Create an authentication context for your application:</p>
                    <pre className="bg-gray-100 p-4 rounded-md overflow-x-auto text-sm">
{`// contexts/AuthContext.tsx
'use client'

import { createContext, useContext, useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'
import { Session, User } from '@supabase/supabase-js'

type AuthContextType = {
  user: User | null
  session: Session | null
  isLoading: boolean
  signUp: (email: string, password: string, fullName: string) => Promise<any>
  signIn: (email: string, password: string) => Promise<any>
  signOut: () => Promise<any>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [session, setSession] = useState<Session | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Check active session
    const getActiveSession = async () => {
      const { data: { session } } = await supabase.auth.getSession()
      setSession(session)
      setUser(session?.user ?? null)
      setIsLoading(false)
    }

    getActiveSession()

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      setSession(session)
      setUser(session?.user ?? null)
      setIsLoading(false)
    })

    return () => {
      subscription.unsubscribe()
    }
  }, [])

  // Sign up function
  const signUp = async (email: string, password: string, fullName: string) => {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          full_name: fullName,
        },
      },
    })

    return { data, error }
  }

  // Sign in function
  const signIn = async (email: string, password: string) => {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    })

    return { data, error }
  }

  // Sign out function
  const signOut = async () => {
    const { error } = await supabase.auth.signOut()
    return { error }
  }

  // Get session function
  const getSession = async () => {
    const { data: { session }, error } = await supabase.auth.getSession()
    return { session, error }
  }

  return (
    <AuthContext.Provider value={{ user, session, isLoading, signUp, signIn, signOut }}>
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => {
  const context = useContext(AuthContext)

  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider')
  }

  return context
}
}
                    </pre>
                  </div>

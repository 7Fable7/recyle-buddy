import Link from "next/link"
import { Recycle } from "lucide-react"

export default function AndroidIntegrationPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="header">
        <Link href="/" className="header-logo">
          <Recycle className="text-primary" style={{ width: "1.5rem", height: "1.5rem" }} />
          <span className="text-lg">Recycle Buddy</span>
        </Link>
        <nav className="header-nav">
          <Link href="/docs" className="header-nav-link">
            Documentation
          </Link>
          <Link href="/" className="header-nav-link">
            Home
          </Link>
        </nav>
      </header>
      <main className="flex-1 p-4 md:p-8">
        <div className="container">
          <h1 className="text-3xl font-bold mb-4">Android App Integration Guide</h1>
          <p className="text-gray-500 mb-8">Learn how to connect your Android app with the Recycle Buddy platform</p>

          <div className="card mb-8">
            <div className="card-header">
              <h2 className="card-title">Setting Up Your Android App</h2>
              <p className="card-description">
                Follow these steps to connect your Android app to the Recycle Buddy platform
              </p>
            </div>
            <div className="card-content">
              <div className="mb-6">
                <h3 className="text-xl font-semibold mb-2">1. Create an API Client</h3>
                <p className="text-gray-600 mb-2">
                  Create a Retrofit API client to communicate with our API endpoints:
                </p>
                <pre className="bg-gray-100 p-4 rounded overflow-x-auto text-sm">
                  {`// RetrofitClient.kt
object RetrofitClient {
    private const val BASE_URL = "https://your-recycle-buddy-app.vercel.app/api/"
    
    private val client = OkHttpClient.Builder()
        .addInterceptor(AuthInterceptor())
        .build()
        
    val instance: Retrofit by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .client(client)
            .build()
    }
}`}
                </pre>
              </div>

              <div className="mb-6">
                <h3 className="text-xl font-semibold mb-2">2. Define API Interfaces</h3>
                <p className="text-gray-600 mb-2">Create API service interfaces:</p>
                <pre className="bg-gray-100 p-4 rounded overflow-x-auto text-sm">
                  {`// RecycleBuddyApi.kt
interface RecycleBuddyApi {
    @POST("auth")
    suspend fun login(@Body loginRequest: LoginRequest): Response<AuthResponse>
    
    @GET("reports")
    suspend fun getReports(@Query("userId") userId: String? = null): Response<List<WasteReport>>
    
    @POST("reports")
    suspend fun createReport(@Body report: WasteReport): Response<WasteReport>
    
    @Multipart
    @POST("upload")
    suspend fun uploadImage(
        @Part image: MultipartBody.Part
    ): Response<UploadResponse>
}`}
                </pre>
              </div>

              <div className="mb-6">
                <h3 className="text-xl font-semibold mb-2">3. Create Data Models</h3>
                <p className="text-gray-600 mb-2">Define data models to match the API responses:</p>
                <pre className="bg-gray-100 p-4 rounded overflow-x-auto text-sm">
                  {`// WasteReport.kt
data class WasteReport(
    val id: String? = null,
    val imageUrl: String? = null,
    val location: String,
    val description: String? = null,
    val category: String,
    val status: String = "pending",
    val date: String? = null,
    val time: String? = null,
    val facility: String? = null,
    val userId: String? = null
)

// AuthResponse.kt
data class AuthResponse(
    val success: Boolean,
    val token: String,
    val user: User
)

// User.kt
data class User(
    val id: String,
    val email: String,
    val name: String
)`}
                </pre>
              </div>
            </div>
          </div>

          <div className="card mb-8">
            <div className="card-header">
              <h2 className="card-title">Authentication Implementation</h2>
              <p className="card-description">Implementing authentication in your Android app</p>
            </div>
            <div className="card-content">
              <div className="mb-6">
                <h3 className="text-xl font-semibold mb-2">1. Create Auth Interceptor</h3>
                <p className="text-gray-600 mb-2">Add authentication token to your requests:</p>
                <pre className="bg-gray-100 p-4 rounded overflow-x-auto text-sm">
                  {`// AuthInterceptor.kt
class AuthInterceptor : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request()
        val token = SharedPrefsManager.getToken()
        
        return if (token != null) {
            val newRequest = request.newBuilder()
                .header("Authorization", "Bearer $token")
                .build()
            chain.proceed(newRequest)
        } else {
            chain.proceed(request)
        }
    }
}`}
                </pre>
              </div>

              <div className="mb-6">
                <h3 className="text-xl font-semibold mb-2">2. Implement Login Flow</h3>
                <p className="text-gray-600 mb-2">Create a ViewModel for authentication:</p>
                <pre className="bg-gray-100 p-4 rounded overflow-x-auto text-sm">
                  {`// AuthViewModel.kt
class AuthViewModel(private val repository: AuthRepository) : ViewModel() {
    private val _loginResult = MutableLiveData<Resource<AuthResponse>>()
    val loginResult: LiveData<Resource<AuthResponse>> = _loginResult
    
    fun login(email: String, password: String) = viewModelScope.launch {
        _loginResult.value = Resource.Loading()
        try {
            val response = repository.login(LoginRequest(email, password))
            if (response.isSuccessful && response.body() != null) {
                val authResponse = response.body()!!
                SharedPrefsManager.saveToken(authResponse.token)
                SharedPrefsManager.saveUser(authResponse.user)
                _loginResult.value = Resource.Success(authResponse)
            } else {
                _loginResult.value = Resource.Error("Authentication failed")
            }
        } catch (e: Exception) {
            _loginResult.value = Resource.Error(e.message ?: "Unknown error")
        }
    }
}`}
                </pre>
              </div>

              <div className="mb-6">
                <h3 className="text-xl font-semibold mb-2">3. Save User Session</h3>
                <p className="text-gray-600 mb-2">Create a SharedPrefs manager for user session:</p>
                <pre className="bg-gray-100 p-4 rounded overflow-x-auto text-sm">
                  {`// SharedPrefsManager.kt
object SharedPrefsManager {
    private const val PREFS_NAME = "RecycleBuddyPrefs"
    private const val KEY_TOKEN = "auth_token"
    private const val KEY_USER_ID = "user_id"
    private const val KEY_USER_EMAIL = "user_email"
    private const val KEY_USER_NAME = "user_name"
    
    private fun getSharedPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }
    
    fun saveToken(token: String) {
        getSharedPrefs(RecycleBuddyApp.instance).edit().putString(KEY_TOKEN, token).apply()
    }
    
    fun getToken(): String? {
        return getSharedPrefs(RecycleBuddyApp.instance).getString(KEY_TOKEN, null)
    }
    
    fun saveUser(user: User) {
        getSharedPrefs(RecycleBuddyApp.instance).edit().apply {
            putString(KEY_USER_ID, user.id)
            putString(KEY_USER_EMAIL, user.email)
            putString(KEY_USER_NAME, user.name)
            apply()
        }
    }
    
    fun clearSession() {
        getSharedPrefs(RecycleBuddyApp.instance).edit().clear().apply()
    }
}`}
                </pre>
              </div>
            </div>
          </div>

          <div className="card mb-8">
            <div className="card-header">
              <h2 className="card-title">Image Upload Implementation</h2>
              <p className="card-description">Handle image uploads in your Android app</p>
            </div>
            <div className="card-content">
              <div className="mb-6">
                <h3 className="text-xl font-semibold mb-2">1. Add Upload Functionality</h3>
                <p className="text-gray-600 mb-2">Implement image selection and upload feature:</p>
                <pre className="bg-gray-100 p-4 rounded overflow-x-auto text-sm">
                  {`// CreateReportViewModel.kt
class CreateReportViewModel(private val repository: ReportRepository) : ViewModel() {
    private val _uploadResult = MutableLiveData<Resource<UploadResponse>>()
    val uploadResult: LiveData<Resource<UploadResponse>> = _uploadResult
    
    private val _createReportResult = MutableLiveData<Resource<WasteReport>>()
    val createReportResult: LiveData<Resource<WasteReport>> = _createReportResult
    
    fun uploadImage(imageFile: File) = viewModelScope.launch {
        _uploadResult.value = Resource.Loading()
        try {
            val response = repository.uploadImage(imageFile)
            if (response.isSuccessful && response.body() != null) {
                _uploadResult.value = Resource.Success(response.body()!!)
            } else {
                _uploadResult.value = Resource.Error("Upload failed")
            }
        } catch (e: Exception) {
            _uploadResult.value = Resource.Error(e.message ?: "Unknown error")
        }
    }
    
    fun createReportWithImage(
        imageFile: File?,
        location: String,
        description: String?,
        category: String
    ) = viewModelScope.launch {
        // First upload the image if available
        if (imageFile != null) {
            _uploadResult.value = Resource.Loading()
            try {
                val uploadResponse = repository.uploadImage(imageFile)
                if (uploadResponse.isSuccessful && uploadResponse.body() != null) {
                    val imageUrl = uploadResponse.body()!!.url
                    // Then create the report with the image URL
                    createReport(imageUrl, location, description, category)
                } else {
                    _uploadResult.value = Resource.Error("Image upload failed")
                }
            } catch (e: Exception) {
                _uploadResult.value = Resource.Error(e.message ?: "Unknown error")
            }
        } else {
            // Create report without image
            createReport(null, location, description, category)
        }
    }
    
    private fun createReport(
        imageUrl: String?,
        location: String,
        description: String?,
        category: String
    ) = viewModelScope.launch {
        _createReportResult.value = Resource.Loading()
        
        try {
            val userId = SharedPrefsManager.getUserId()
            val report = WasteReport(
                imageUrl = imageUrl,
                location = location,
                description = description,
                category = category,
                userId = userId
            )
            
            val response = repository.createReport(report)
            if (response.isSuccessful && response.body() != null) {
                _createReportResult.value = Resource.Success(response.body()!!)
            } else {
                _createReportResult.value = Resource.Error("Failed to create report")
            }
        } catch (e: Exception) {
            _createReportResult.value = Resource.Error(e.message ?: "Unknown error")
        }
    }
}`}
                </pre>
              </div>

              <div className="mb-6">
                <h3 className="text-xl font-semibold mb-2">2. Implement Image Capture</h3>
                <p className="text-gray-600 mb-2">Create an Activity to capture or select an image:</p>
                <pre className="bg-gray-100 p-4 rounded overflow-x-auto text-sm">
                  {`// CreateReportActivity.kt - Image selection part
private fun selectImage() {
    val options = arrayOf("Take Photo", "Choose from Gallery", "Cancel")
    val builder = AlertDialog.Builder(this)
    builder.setTitle("Add Photo")
    builder.setItems(options) { dialog, item ->
        when (options[item]) {
            "Take Photo" -> {
                if (checkCameraPermission()) {
                    takePhotoFromCamera()
                } else {
                    requestCameraPermission()
                }
            }
            "Choose from Gallery" -> {
                if (checkStoragePermission()) {
                    choosePhotoFromGallery()
                } else {
                    requestStoragePermission()
                }
            }
            "Cancel" -> dialog.dismiss()
        }
    }
    builder.show()
}

// Permission handling methods...

private fun takePhotoFromCamera() {
    val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
    startActivityForResult(intent, REQUEST_CAMERA)
}

private fun choosePhotoFromGallery() {
    val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
    startActivityForResult(intent, SELECT_FROM_GALLERY)
}

override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
    super.onActivityResult(requestCode, resultCode, data)
    if (resultCode == Activity.RESULT_OK) {
        when (requestCode) {
            REQUEST_CAMERA -> {
                val thumbnail = data?.extras?.get("data") as Bitmap
                imageFile = saveBitmapToFile(thumbnail)
                binding.imagePreview.setImageBitmap(thumbnail)
                binding.imagePreview.visibility = View.VISIBLE
            }
            SELECT_FROM_GALLERY -> {
                val selectedImage = data?.data
                imageFile = getFileFromUri(selectedImage!!)
                binding.imagePreview.setImageURI(selectedImage)
                binding.imagePreview.visibility = View.VISIBLE
            }
        }
    }
}`}
                </pre>
              </div>
            </div>
          </div>

          <div className="card">
            <div className="card-header">
              <h2 className="card-title">Data Synchronization</h2>
              <p className="card-description">Keep your Android app in sync with the platform</p>
            </div>
            <div className="card-content">
              <div className="mb-6">
                <h3 className="text-xl font-semibold mb-2">1. Implement Background Sync</h3>
                <p className="text-gray-600 mb-2">Create a WorkManager for periodic syncing:</p>
                <pre className="bg-gray-100 p-4 rounded overflow-x-auto text-sm">
                  {`// SyncWorker.kt
class SyncWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    private val repository = ReportRepository()
    
    override suspend fun doWork(): Result {
        try {
            val userId = SharedPrefsManager.getUserId() ?: return Result.failure()
            
            // Fetch latest reports from server
            val response = repository.getReports(userId)
            if (response.isSuccessful) {
                val reports = response.body() ?: emptyList()
                // Update local database
                AppDatabase.getInstance(applicationContext).reportDao().insertAll(reports)
                return Result.success()
            }
            return Result.retry()
        } catch (e: Exception) {
            return Result.failure()
        }
    }
}`}
                </pre>
              </div>

              <div className="mb-6">
                <h3 className="text-xl font-semibold mb-2">2. Schedule Periodic Sync</h3>
                <p className="text-gray-600 mb-2">Setup background sync when app starts:</p>
                <pre className="bg-gray-100 p-4 rounded overflow-x-auto text-sm">
                  {`// RecycleBuddyApp.kt - Application class
override fun onCreate() {
    super.onCreate()
    instance = this
    setupWorkManager()
}

private fun setupWorkManager() {
    val constraints = Constraints.Builder()
        .setRequiredNetworkType(NetworkType.CONNECTED)
        .build()
    
    val syncRequest = PeriodicWorkRequestBuilder<SyncWorker>(15, TimeUnit.MINUTES)
        .setConstraints(constraints)
        .build()
    
    WorkManager.getInstance(this).enqueueUniquePeriodicWork(
        "RecycleBuddySync",
        ExistingPeriodicWorkPolicy.KEEP,
        syncRequest
    )
}`}
                </pre>
              </div>
            </div>
          </div>
        </div>
      </main>
      <footer className="flex flex-col sm:flex-row gap-2 py-6 border-t px-4">
        <p className="text-xs text-gray-500">© 2024 Recycle Buddy. All rights reserved.</p>
      </footer>
    </div>
  )
}

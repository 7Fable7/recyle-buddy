"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Recycle, Loader2, Building2, Truck, MapPin, Phone } from "lucide-react"

export default function FacilityProfilePage() {
  const [isLoading, setIsLoading] = useState(false)
  const [facilityProfile, setFacilityProfile] = useState({
    name: "Green Recycling Co.",
    email: "contact@greenrecycling.com",
    phone: "+1 (555) 987-6543",
    address: "789 Industrial Way, Anytown, USA",
    description:
      "Specializing in responsible recycling and waste management solutions for residential and commercial clients.",
    serviceArea: "25 miles",
    wasteTypes: "General Waste, E-Waste",
    fleetSize: "5 vehicles",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFacilityProfile((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      // In a real implementation, you would update the facility profile in your database
      await new Promise((resolve) => setTimeout(resolve, 1000)) // Simulate API call
      alert("Profile updated successfully!")
    } catch (error) {
      console.error("Error updating profile:", error)
      alert("Failed to update profile. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex flex-col min-h-screen">
      <header className="px-4 lg:px-6 h-16 flex items-center border-b">
        <Link href="/" className="flex items-center gap-2 font-semibold">
          <Recycle className="h-6 w-6 text-green-600" />
          <span className="text-lg">WasteConnect</span>
          <Badge className="ml-2">Facility Portal</Badge>
        </Link>
        <nav className="ml-auto flex gap-4 sm:gap-6">
          <Link href="/facilities" className="text-sm font-medium hover:underline underline-offset-4">
            Available Pickups
          </Link>
          <Link href="/facilities/scheduled" className="text-sm font-medium hover:underline underline-offset-4">
            My Scheduled Pickups
          </Link>
          <Link href="/facilities/profile" className="text-sm font-medium hover:underline underline-offset-4">
            Facility Profile
          </Link>
          <Link href="/logout" className="text-sm font-medium hover:underline underline-offset-4">
            Logout
          </Link>
        </nav>
      </header>
      <main className="flex-1 p-4 md:p-6 lg:p-8">
        <div className="max-w-3xl mx-auto space-y-8">
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Facility Profile</h1>
            <p className="text-gray-500">Manage your facility information and service details</p>
          </div>

          <Card>
            <CardHeader>
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="p-4 bg-green-100 rounded-lg">
                  <Building2 className="h-12 w-12 text-green-600" />
                </div>
                <div>
                  <CardTitle>Facility Information</CardTitle>
                  <CardDescription>Update your facility details and service offerings</CardDescription>
                </div>
              </div>
            </CardHeader>
            <form onSubmit={handleSubmit}>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Facility Name</Label>
                    <Input id="name" name="name" value={facilityProfile.name} onChange={handleChange} required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      value={facilityProfile.email}
                      onChange={handleChange}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone" className="flex items-center gap-1">
                      <Phone className="h-4 w-4" /> Contact Phone
                    </Label>
                    <Input id="phone" name="phone" value={facilityProfile.phone} onChange={handleChange} required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="address" className="flex items-center gap-1">
                      <MapPin className="h-4 w-4" /> Address
                    </Label>
                    <Input
                      id="address"
                      name="address"
                      value={facilityProfile.address}
                      onChange={handleChange}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="serviceArea">Service Area Radius</Label>
                    <Input
                      id="serviceArea"
                      name="serviceArea"
                      value={facilityProfile.serviceArea}
                      onChange={handleChange}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="wasteTypes">Waste Types Handled</Label>
                    <Input
                      id="wasteTypes"
                      name="wasteTypes"
                      value={facilityProfile.wasteTypes}
                      onChange={handleChange}
                      required
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="fleetSize" className="flex items-center gap-1">
                    <Truck className="h-4 w-4" /> Fleet Size
                  </Label>
                  <Input id="fleetSize" name="fleetSize" value={facilityProfile.fleetSize} onChange={handleChange} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="description">Facility Description</Label>
                  <Textarea
                    id="description"
                    name="description"
                    value={facilityProfile.description}
                    onChange={handleChange}
                    rows={4}
                  />
                </div>
              </CardContent>
              <CardFooter>
                <Button className="bg-green-600 hover:bg-green-700" disabled={isLoading}>
                  {isLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Saving...
                    </>
                  ) : (
                    "Save Changes"
                  )}
                </Button>
              </CardFooter>
            </form>
          </Card>
        </div>
      </main>
    </div>
  )
}

"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { Loader2 } from "lucide-react"

export default function LogoutPage() {
  const router = useRouter()

  useEffect(() => {
    // In a real implementation, you would clear authentication tokens
    const logout = async () => {
      // Simulate API call to logout
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Redirect to home page
      router.push("/")
    }

    logout()
  }, [router])

  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="text-center">
        <Loader2 className="mx-auto h-8 w-8 text-green-600 animate-spin" />
        <h1 className="mt-4 text-xl font-bold">Logging out...</h1>
        <p className="text-gray-500 mt-2">You will be redirected shortly.</p>
      </div>
    </div>
  )
}

"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Recycle, ArrowLeft, MapPin, Clock, Calendar, CheckCircle } from "lucide-react"

export default function ReportDetailsPage({ params }: { params: { id: string } }) {
  const [report, setReport] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // In a real implementation, fetch the report data from your database
    const fetchReport = async () => {
      try {
        // Simulate API call
        await new Promise((resolve) => setTimeout(resolve, 500))

        // Mock data based on the ID
        setReport({
          id: params.id,
          imageUrl: "/placeholder.svg?height=400&width=600",
          location: params.id === "1" ? "123 Main St, Anytown" : "456 Oak Ave, Somewhere",
          coordinates: "40.7128, -74.0060",
          description: params.id === "1" ? "Plastic waste and cardboard boxes" : "Electronic waste",
          category: params.id === "1" ? "General Waste" : "E-Waste",
          status: params.id === "1" ? "scheduled" : "pending",
          date: params.id === "1" ? "2024-05-05" : null,
          time: params.id === "1" ? "10:00 AM - 12:00 PM" : null,
          facility: params.id === "1" ? "Green Recycling Co." : null,
          submittedAt: params.id === "1" ? "2024-04-28" : "2024-04-30",
        })
      } catch (error) {
        console.error("Error fetching report:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchReport()
  }, [params.id])

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return (
          <Badge variant="outline" className="flex items-center gap-1">
            <Clock className="h-3 w-3" /> Pending
          </Badge>
        )
      case "scheduled":
        return (
          <Badge className="bg-blue-500 flex items-center gap-1">
            <Calendar className="h-3 w-3" /> Scheduled
          </Badge>
        )
      case "completed":
        return (
          <Badge className="bg-green-500 flex items-center gap-1">
            <CheckCircle className="h-3 w-3" /> Completed
          </Badge>
        )
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  return (
    <div className="flex flex-col min-h-screen">
      <header className="px-4 lg:px-6 h-16 flex items-center border-b">
        <Link href="/" className="flex items-center gap-2 font-semibold">
          <Recycle className="h-6 w-6 text-green-600" />
          <span className="text-lg">WasteConnect</span>
        </Link>
        <nav className="ml-auto flex gap-4 sm:gap-6">
          <Link href="/dashboard" className="text-sm font-medium hover:underline underline-offset-4">
            Dashboard
          </Link>
          <Link href="/profile" className="text-sm font-medium hover:underline underline-offset-4">
            Profile
          </Link>
          <Link href="/logout" className="text-sm font-medium hover:underline underline-offset-4">
            Logout
          </Link>
        </nav>
      </header>
      <main className="flex-1 p-4 md:p-8">
        <div className="max-w-4xl mx-auto">
          <div className="mb-6">
            <Link href="/dashboard">
              <Button variant="ghost" className="pl-0">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Dashboard
              </Button>
            </Link>
          </div>

          {loading ? (
            <div className="flex justify-center items-center h-64">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600"></div>
            </div>
          ) : report ? (
            <Card className="overflow-hidden">
              <div className="aspect-video w-full overflow-hidden">
                <img
                  src={report.imageUrl || "/placeholder.svg"}
                  alt={`Waste report ${report.id}`}
                  className="h-full w-full object-cover"
                />
              </div>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <CardTitle className="text-xl">Waste Report #{report.id}</CardTitle>
                  {getStatusBadge(report.status)}
                </div>
                <CardDescription>Submitted on {report.submittedAt}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <h3 className="font-medium text-gray-900">Category</h3>
                      <Badge variant="outline" className="mt-1 bg-gray-100">
                        {report.category}
                      </Badge>
                    </div>
                    <div>
                      <h3 className="font-medium text-gray-900">Location</h3>
                      <p className="text-gray-500 flex items-center gap-1 mt-1">
                        <MapPin className="h-4 w-4" />
                        {report.location}
                      </p>
                    </div>
                    <div>
                      <h3 className="font-medium text-gray-900">Description</h3>
                      <p className="text-gray-500 mt-1">{report.description}</p>
                    </div>
                  </div>

                  {report.status === "scheduled" && (
                    <div className="bg-blue-50 p-4 rounded-lg space-y-2">
                      <h3 className="font-medium text-blue-800">Pickup Information</h3>
                      <div>
                        <p className="text-sm text-blue-800 flex items-center gap-1">
                          <Calendar className="h-4 w-4" /> Date: {report.date}
                        </p>
                        <p className="text-sm text-blue-800 flex items-center gap-1 mt-1">
                          <Clock className="h-4 w-4" /> Time: {report.time}
                        </p>
                        <p className="text-sm text-blue-800 mt-2">By: {report.facility}</p>
                      </div>
                    </div>
                  )}

                  {report.status === "completed" && (
                    <div className="bg-green-50 p-4 rounded-lg space-y-2">
                      <h3 className="font-medium text-green-800">Pickup Completed</h3>
                      <div>
                        <p className="text-sm text-green-800 flex items-center gap-1">
                          <Calendar className="h-4 w-4" /> Date: {report.date}
                        </p>
                        <p className="text-sm text-green-800 flex items-center gap-1 mt-1">
                          <Clock className="h-4 w-4" /> Time: {report.time}
                        </p>
                        <p className="text-sm text-green-800 mt-2">By: {report.facility}</p>
                      </div>
                    </div>
                  )}
                </div>

                {report.status === "pending" && (
                  <div className="bg-yellow-50 p-4 rounded-lg">
                    <p className="text-sm text-yellow-800">
                      Your report is pending. A waste management facility will schedule a pickup soon.
                    </p>
                  </div>
                )}
              </CardContent>
              {report.status === "pending" && (
                <CardFooter>
                  <Button variant="outline" className="w-full border-red-300 text-red-500 hover:bg-red-50">
                    Cancel Report
                  </Button>
                </CardFooter>
              )}
            </Card>
          ) : (
            <div className="text-center py-12">
              <h2 className="text-xl font-bold">Report not found</h2>
              <p className="text-gray-500 mt-2">The report you're looking for doesn't exist or has been removed.</p>
              <Link href="/dashboard">
                <Button className="mt-4 bg-green-600 hover:bg-green-700">Go to Dashboard</Button>
              </Link>
            </div>
          )}
        </div>
      </main>
    </div>
  )
}
